# Hardened Binary Evaluation Lab

A small, reproducible CI lab that compares C++20 demo binaries built with GCC and Clang under common hardening profiles. **Every program here is an invented demo written for this repository.** The overflow and use-after-free are intentional teaching examples; never copy their unsafe patterns into production.

<!-- CI-OUTPUT:START -->

First GitHub Actions run will replace this text with the real run URL, pytest result count, and generated reports.

<!-- CI-OUTPUT:END -->

## Architecture

```mermaid
flowchart LR
  P[Three C++20 demo programs] --> B[build_matrix.py]
  C[GCC and Clang] --> B
  H[Hardening profiles] --> B
  B --> E[Correctness and pytest]
  B --> X[Local marker exploit probe]
  B --> T[Repeated benchmark medians]
  E --> R[Markdown, CSV and chart]
  X --> R
  T --> R
  B --> A[readelf and objdump evidence]
  A --> R
  R --> U[GitHub Actions artifact and README]
```

## What is measured

The matrix builds all three programs with GCC and Clang using baseline, `-fstack-protector-strong`, PIE plus full RELRO, `_FORTIFY_SOURCE=3`, control-flow protection, and two link-time randomized function-order seeds. Correctness checks safe parser output, a stable completion marker for the deliberately unsafe UAF demo, and the compute benchmark checksum across every build. Any compiler or profile output mismatch fails pytest.

The benchmark runs each compute binary seven times and reports its median and percentage difference from the same compiler's baseline. Runtime results are runner-specific observations, not universal guarantees. A standard-library Python probe uses a baseline-only local address to check whether a control-flow marker in the overflow demo is reached. It uses no shellcode, external target, or arbitrary command execution. The probe is deliberately limited to these lab binaries.

## Reports

Download the `hardened-binary-evaluation-*` artifact from the Actions run. It contains `evaluation.md`, `results.csv`, `overhead.png`, `binary-analysis.md`, the build manifest, benchmark observations, exploit outcomes, and pytest XML. The Markdown report summarizes pass/fail and measured overhead; the CSV is convenient for follow-up analysis; the chart compares median overhead by compiler. The binary analysis records real `readelf` and `objdump` evidence from CI.

## Threat model

This lab assumes the reader runs only the repository's own small demo programs on ephemeral GitHub-hosted runners. The overflow and use-after-free introduce undefined behavior and are intentionally unsafe. The security probe only observes whether a local demo reaches a benign marker. It does not target third-party software or provide a general-purpose payload. Sanitizers and hardening are mitigations with platform and compiler limits; passing this lab is not a security certification.

## Run policy

Compilation, pytest, benchmarks, exploit checks, and report generation are performed by the Ubuntu GitHub Actions workflow. No Docker, API key, external model, or additional service account is used. The repository contains all source code. Pushes, pull requests, and manual workflow dispatch execute the evaluation; successful branch runs commit the generated reports and a short real-run summary to this README. The workflow uploads an artifact even when evaluation fails, when evidence files exist.

## Design decisions

- Keep the demos tiny so a compiler's relevant transformation is easy to inspect.
- Use C++ standard-library behavior and stable output for correctness. The UAF demonstration never asserts on the undefined read value.
- Separate compiler baselines so performance overhead is compared within one compiler.
- Use seven fresh-process samples and a median to reduce noise from one unusually fast or slow run.
- Keep exploit verification local and marker-based. A stale address is used for hardened/layout variants; no injected instructions are involved.
- Treat function-order randomization as a linker experiment and retain the exact effective flags in `build/manifest.json`.
- Generate evidence in CI rather than checking runner-specific timing into source control.

## Roadmap

- Add AddressSanitizer and UndefinedBehaviorSanitizer profiles as distinct diagnostic builds.
- Compare additional compilers and optimization levels.
- Track overhead distributions across repeated workflow runs, with runner metadata.
- Add a safe parser implementation beside the intentionally vulnerable example.
- Extend ELF analysis to inspect stack executability and compiler property notes.

## Repository layout

```text
programs/          C++20 demo programs
harness/           matrix, probe, benchmark and report scripts
tests/             pytest correctness, security and report checks
.github/workflows/ GitHub Actions evaluation
reports/           generated CI comparison reports
```
