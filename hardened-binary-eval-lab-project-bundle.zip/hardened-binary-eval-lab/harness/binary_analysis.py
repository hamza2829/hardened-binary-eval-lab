#!/usr/bin/env python3
"""Capture concise, real ELF evidence with binutils for the CI report."""
from __future__ import annotations
import json, pathlib, re, subprocess
ROOT=pathlib.Path(__file__).resolve().parents[1]; builds=json.loads((ROOT/"build/manifest.json").read_text())["builds"]
def run(*args): return subprocess.check_output(args,text=True,stderr=subprocess.STDOUT)
def find(compiler,profile): return ROOT/next(b["binary"] for b in builds if b["compiler"]==compiler and b["profile"]==profile and b["program"]=="overflow_parser")
base=find("g++","baseline"); pie=find("g++","pie-full-relro"); ssp=find("g++","stack-protector-strong"); fort=find("g++","fortify-source-3")
def elf(path):
    header=run("readelf","-h",str(path)); dynamic=run("readelf","-d",str(path)); program=run("readelf","-l",str(path)); symbols=run("readelf","-Ws",str(path))
    return {"type":re.search(r"Type:\s+(\S+)",header).group(1),"relro":"GNU_RELRO" in program,"bind_now":"BIND_NOW" in dynamic or "FLAGS_1.*NOW" in dynamic,"stack_chk_fail":"__stack_chk_fail" in symbols,"strcpy_chk":"__strcpy_chk" in symbols}
items={"baseline":elf(base),"pie_full_relro":elf(pie),"stack_protector":elf(ssp),"fortify":elf(fort)}
dis=run("objdump","-d","-Mintel",str(ssp)); ix=dis.find("<vulnerable_parser>"); snippet="\n".join(dis[ix:ix+1100].splitlines()[:22])
text="# Binary analysis (captured in CI)\n\nThis is evidence from the exact GCC demo binaries produced in this run.\n\n"
text+="| Build | ELF type | GNU_RELRO | immediate binding | stack check | fortified copy |\n|---|---|---:|---:|---:|---:|\n"
for name,x in items.items(): text+=f"| {name} | {x['type']} | {x['relro']} | {x['bind_now']} | {x['stack_chk_fail']} | {x['strcpy_chk']} |\n"
text+="\n`readelf -h/-l/-d/-Ws` confirms the ELF type, RELRO segment, immediate binding and imported checking symbols. The PIE row should be `DYN` with RELRO and immediate binding; the stack-protector and FORTIFY rows expose their corresponding runtime checks.\n\nRepresentative `objdump -d -Mintel` excerpt for the stack-protected parser:\n\n```asm\n"+snippet+"\n```\n\nThe canary check appears in the function epilogue (often via `__stack_chk_fail`). The FORTIFY build redirects the known-size `strcpy` to a checked variant when the compiler can prove the object size. Exact instruction sequences vary by GCC version. These controls are separate: PIE/RELRO primarily constrain address reuse and relocation state, while stack protection detects this overwrite at function return.\n"
(ROOT/"reports").mkdir(exist_ok=True); (ROOT/"reports/binary-analysis.md").write_text(text)
(ROOT/"build/binary-analysis.json").write_text(json.dumps(items,indent=2)+"\n")
