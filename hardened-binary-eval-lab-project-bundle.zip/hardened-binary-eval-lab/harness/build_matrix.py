#!/usr/bin/env python3
"""Build every demo with GCC/Clang and all requested hardening profiles."""
from __future__ import annotations
import json, pathlib, shutil, subprocess, sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
OUT = ROOT / "build"
PROGRAMS = ["overflow_parser", "use_after_free", "compute_benchmark"]
PROFILES = {
    "baseline": [],
    "stack-protector-strong": ["-fstack-protector-strong"],
    "pie-full-relro": ["-fstack-protector-strong", "-fPIE", "-pie", "-Wl,-z,relro,-z,now"],
    "fortify-source-3": ["-fstack-protector-strong", "-D_FORTIFY_SOURCE=3"],
    "control-flow-protection": ["-fstack-protector-strong", "-fcf-protection=full"],
    "random-layout-seed-101": ["-ffunction-sections", "-fuse-ld=lld", "-Wl,--shuffle-sections=.text.*=101"],
    "random-layout-seed-202": ["-ffunction-sections", "-fuse-ld=lld", "-Wl,--shuffle-sections=.text.*=202"],
}
# Explicitly negate toolchain distro defaults so baseline is genuinely unprotected.
# Later profile flags re-enable stack protection where required.
BASE = ["-std=c++20", "-O2", "-fno-omit-frame-pointer", "-fno-pie", "-no-pie", "-fno-stack-protector"]

def main() -> None:
    OUT.mkdir(exist_ok=True)
    manifest=[]
    for compiler in ("g++", "clang++"):
        path=shutil.which(compiler)
        if not path: raise SystemExit(f"Required compiler missing: {compiler}")
        for profile, flags in PROFILES.items():
            for program in PROGRAMS:
                # Only random-layout profiles require LLD; all other combinations still run.
                effective=list(BASE)+list(flags)
                if profile.startswith("random-layout") and shutil.which("ld.lld") is None:
                    effective.remove("-fuse-ld=lld")
                    effective=[f for f in effective if not f.startswith("-Wl,--shuffle-sections")]
                target=OUT/"bin"/compiler.replace("+","p")/profile/f"{program}"
                target.parent.mkdir(parents=True,exist_ok=True)
                cmd=[path,*effective,str(ROOT/"programs"/f"{program}.cpp"),"-o",str(target)]
                proc=subprocess.run(cmd,text=True,capture_output=True)
                if proc.returncode:
                    raise SystemExit(f"Build failed: {' '.join(cmd)}\n{proc.stderr}")
                manifest.append({"compiler":compiler,"profile":profile,"program":program,"binary":str(target.relative_to(ROOT)),"flags":effective})
    (OUT/"manifest.json").write_text(json.dumps({"profiles":list(PROFILES),"builds":manifest},indent=2)+"\n")
    print(f"Built {len(manifest)} binaries using GCC and Clang")

if __name__ == "__main__": main()
