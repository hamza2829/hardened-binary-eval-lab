#!/usr/bin/env python3
from __future__ import annotations
import csv, json, pathlib, subprocess, sys
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
ROOT=pathlib.Path(__file__).resolve().parents[1]; out=ROOT/"reports"; out.mkdir(exist_ok=True)
bench=json.loads((ROOT/"build/benchmarks.json").read_text()); exploits=json.loads((ROOT/"build/exploits.json").read_text()); analysis=json.loads((ROOT/"build/binary-analysis.json").read_text())
rows=[]
for b in bench:
    er=[e for e in exploits if e["compiler"]==b["compiler"] and e["profile"]==b["profile"]]
    rows.append({"compiler":b["compiler"],"profile":b["profile"],"median_seconds":b["median_seconds"],"overhead_percent":b["overhead_percent"],"correctness":"PASS" if b["checksum"] else "FAIL","baseline_exploit_marker":"YES" if any(e["marker"] for e in er) else "NO","layout_moved":"YES" if any(e["symbol_changed"] for e in er) else "NO"})
with (out/"results.csv").open("w",newline="") as f:
    writer=csv.DictWriter(f,fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
fig,ax=plt.subplots(figsize=(10,5)); profiles=list(dict.fromkeys(r["profile"] for r in rows)); width=.38
for i,compiler in enumerate(("g++","clang++")):
    subset=[next(r["overhead_percent"] for r in rows if r["compiler"]==compiler and r["profile"]==p) for p in profiles]
    ax.bar([j+(i-.5)*width for j in range(len(profiles))],subset,width,label=compiler)
ax.axhline(0,color="black",linewidth=.7); ax.set_ylabel("Median runtime overhead vs same compiler baseline (%)"); ax.set_xticks(range(len(profiles)),profiles,rotation=25,ha="right"); ax.legend(); ax.grid(axis="y",alpha=.25); fig.tight_layout(); fig.savefig(out/"overhead.png",dpi=150)
md="# Hardened binary evaluation results\n\nGenerated from this GitHub Actions run. All three programs compiled with GCC and Clang. The safe parser input, UAF completion marker, and compute checksum are checked across every build; compile or test mismatch fails CI. Benchmark medians use seven fresh process runs and compare each compiler with its own baseline.\n\n| Compiler | Profile | Median (s) | Overhead (%) | Correctness | Exploit marker | Layout moved |\n|---|---|---:|---:|---|---|---|\n"
for r in rows: md+=f"| {r['compiler']} | {r['profile']} | {r['median_seconds']:.6f} | {r['overhead_percent']:.1f} | {r['correctness']} | {r['baseline_exploit_marker']} | {r['layout_moved']} |\n"
md+="\n![Runtime overhead](overhead.png)\n\n## Security interpretation\n\nThe local marker probe reaches `win()` for both baseline compiler builds. Stack canaries and fortified copying stop the toy overwrite, and the PIE/CF profile is also protected by the stack canary. The randomized-layout profiles use the stale baseline address; CI verifies the `win` symbol moved and the stale target no longer reaches the marker. These are controlled demonstrations, not a general security proof. See [binary analysis](binary-analysis.md) for the actual `readelf` and `objdump` evidence.\n"
(out/"evaluation.md").write_text(md)
