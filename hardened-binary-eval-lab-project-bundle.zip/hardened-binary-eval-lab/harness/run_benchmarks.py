#!/usr/bin/env python3
from __future__ import annotations
import json, pathlib, statistics, subprocess, time
ROOT=pathlib.Path(__file__).resolve().parents[1]; manifest=json.loads((ROOT/"build/manifest.json").read_text()); rows=[]
for b in manifest["builds"]:
    if b["program"]!="compute_benchmark": continue
    samples=[]; expected=None
    for _ in range(7):
        t=time.perf_counter(); p=subprocess.run([str(ROOT/b["binary"])],capture_output=True,check=True); samples.append(time.perf_counter()-t)
        output=p.stdout.decode().strip(); expected=expected or output
        if output!=expected: raise SystemExit(f"Non-deterministic checksum: {b}")
    rows.append({"compiler":b["compiler"],"profile":b["profile"],"median_seconds":statistics.median(samples),"samples_seconds":samples,"checksum":expected})
for row in rows:
    base=next(r["median_seconds"] for r in rows if r["compiler"]==row["compiler"] and r["profile"]=="baseline")
    row["overhead_percent"]=(row["median_seconds"]/base-1)*100
(ROOT/"build/benchmarks.json").write_text(json.dumps(rows,indent=2)+"\n")
print(f"Measured {len(rows)} compiler/profile combinations, 7 repetitions each")
