#!/usr/bin/env python3
from __future__ import annotations
import json, pathlib, sys
from exploit_overflow import probe, symbol

ROOT=pathlib.Path(__file__).resolve().parents[1]
manifest=json.loads((ROOT/"build/manifest.json").read_text())
results=[]
for compiler in ("g++","clang++"):
    builds=[b for b in manifest["builds"] if b["compiler"]==compiler and b["program"]=="overflow_parser"]
    baseline=next(b for b in builds if b["profile"]=="baseline")
    baseline_path=ROOT/baseline["binary"]
    base_addr=symbol(baseline_path)
    for b in builds:
        path=ROOT/b["binary"]
        result=probe(path,None if b["profile"]=="baseline" else base_addr)
        result.update({"compiler":compiler,"profile":b["profile"],"symbol_changed":symbol(path)!=base_addr})
        expected=(b["profile"]=="baseline")
        result["expected_marker"]=expected
        results.append(result)
        if result["marker"]!=expected:
            print(f"Unexpected exploit marker for {compiler}/{b['profile']}: {result}",file=sys.stderr); sys.exit(1)
        if b["profile"].startswith("random-layout") and not result["symbol_changed"]:
            print(f"Randomized layout did not move win symbol for {compiler}/{b['profile']}",file=sys.stderr); sys.exit(1)
(ROOT/"build/exploits.json").write_text(json.dumps(results,indent=2)+"\n")
print(f"Exploit marker succeeded only on baseline: {len(results)} local probes")
