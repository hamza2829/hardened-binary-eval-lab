#!/usr/bin/env python3
import pathlib, re, xml.etree.ElementTree as ET, os
root=pathlib.Path(__file__).resolve().parents[1]; readme=root/"README.md"; content=readme.read_text(); report=root/"reports/evaluation.md"
xml=root/"build/pytest-results.xml"; suite=ET.parse(xml).getroot(); totals={k:int(suite.attrib.get(k,0)) for k in ("tests","failures","errors","skipped")}
url=os.environ.get("GITHUB_SERVER_URL","https://github.com")+"/"+os.environ.get("GITHUB_REPOSITORY","hamza2829/hardened-binary-eval-lab")+"/actions/runs/"+os.environ.get("GITHUB_RUN_ID","run")
section=f"\n**Latest CI run:** [run {os.environ.get('GITHUB_RUN_NUMBER','')} — {totals['tests']} tests, {totals['failures']+totals['errors']} failures]({url}). The generated [evaluation report](reports/evaluation.md), [CSV](reports/results.csv), [chart](reports/overhead.png), and [binary analysis](reports/binary-analysis.md) are committed from this run.\n"
content=re.sub(r"<!-- CI-OUTPUT:START -->.*?<!-- CI-OUTPUT:END -->", "<!-- CI-OUTPUT:START -->"+section+"<!-- CI-OUTPUT:END -->",content,flags=re.S); readme.write_text(content)
