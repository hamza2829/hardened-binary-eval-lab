#include <cstdint>
#include <cstdio>
#include <vector>

int main() {
  constexpr std::size_t n = 110;
  std::vector<std::uint64_t> a(n*n), b(n*n), c(n*n);
  for (std::size_t i=0;i<n*n;i++) { a[i]=(i*17+3)%101; b[i]=(i*29+7)%103; }
  for (std::size_t i=0;i<n;i++) for (std::size_t k=0;k<n;k++) {
    const auto x=a[i*n+k];
    for (std::size_t j=0;j<n;j++) c[i*n+j]+=x*b[k*n+j];
  }
  std::uint64_t hash=1469598103934665603ULL;
  for (auto x:c) { hash^=x; hash*=1099511628211ULL; }
  std::printf("COMPUTE_CHECKSUM:%llu\n", static_cast<unsigned long long>(hash));
}
