#include <cstdio>
#include <cstdlib>
#include <cstring>

// Demo-only marker. The exploit harness checks control flow reaches here;
// it does not execute a shell or inject code.
extern "C" __attribute__((noinline)) void win() {
  static constexpr char marker[] = "EXPLOIT_OK\n";
  asm volatile("mov $1, %%rax; mov $1, %%rdi; mov %0, %%rsi; mov $11, %%rdx; syscall; mov $60, %%rax; xor %%rdi, %%rdi; syscall" :: "r"(marker) : "rax", "rdi", "rsi", "rdx");
  __builtin_unreachable();
}

extern "C" __attribute__((noinline)) int vulnerable_parser(const char *input) {
  char buffer[32];
  std::strcpy(buffer, input); // Intentionally unsafe for hardening evaluation.
  return static_cast<unsigned char>(buffer[0]);
}

int main(int argc, char **argv) {
  if (argc != 2) { std::puts("USAGE: overflow_parser <input>"); return 2; }
  const int first = vulnerable_parser(argv[1]);
  if (first == 's' && std::strcmp(argv[1], "safe") == 0) std::puts("PARSER_OK:SAFE_INPUT");
  else std::puts("PARSER_REJECTED");
}
