#include <cstdlib>
#include <cstdio>

int main() {
  auto *p = static_cast<volatile int *>(std::malloc(sizeof(int)));
  if (!p) return 2;
  *const_cast<int *>(p) = 17;
  std::free(const_cast<int *>(p));
  // Deliberate use-after-free. Do not infer a value from this undefined read.
  (void)*p;
  std::puts("UAF_DEMO_COMPLETE");
}
