import json, pathlib, subprocess
import pytest
ROOT=pathlib.Path(__file__).resolve().parents[1]
BUILDS=json.loads((ROOT/"build/manifest.json").read_text())["builds"]
@pytest.mark.parametrize("build",BUILDS,ids=lambda b:f"{b['compiler']}-{b['profile']}-{b['program']}")
def test_all_binaries_emit_expected_stable_output(build):
    binary=ROOT/build["binary"]
    if build["program"]=="overflow_parser":
        result=subprocess.run([str(binary),"safe"],capture_output=True,text=True,check=True); assert result.stdout=="PARSER_OK:SAFE_INPUT\n"
    elif build["program"]=="use_after_free":
        result=subprocess.run([str(binary)],capture_output=True,text=True,check=True); assert result.stdout=="UAF_DEMO_COMPLETE\n"
    else:
        result=subprocess.run([str(binary)],capture_output=True,text=True,check=True); assert result.stdout.startswith("COMPUTE_CHECKSUM:") and result.stdout.strip().split(":")[1].isdigit()
@pytest.mark.parametrize("program",["overflow_parser","use_after_free","compute_benchmark"])
def test_compilers_agree_on_program_output(program):
    samples=[]
    for compiler in ("g++","clang++"):
        build=next(b for b in BUILDS if b["compiler"]==compiler and b["profile"]=="baseline" and b["program"]==program)
        args=[str(ROOT/build["binary"]),"safe"] if program=="overflow_parser" else [str(ROOT/build["binary"])]
        samples.append(subprocess.check_output(args,text=True))
    assert samples[0]==samples[1]
@pytest.mark.parametrize("program",["overflow_parser","use_after_free","compute_benchmark"])
def test_all_profiles_have_identical_output(program):
    outputs=[]
    for build in BUILDS:
        if build["program"]!=program: continue
        args=[str(ROOT/build["binary"]),"safe"] if program=="overflow_parser" else [str(ROOT/build["binary"])]
        outputs.append(subprocess.check_output(args,text=True))
    assert len(outputs)==28 and len(set(outputs))==1
