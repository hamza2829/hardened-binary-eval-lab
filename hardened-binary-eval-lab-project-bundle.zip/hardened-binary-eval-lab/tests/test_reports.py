import csv, pathlib
ROOT=pathlib.Path(__file__).resolve().parents[1]
def test_markdown_report_has_each_profile():
    text=(ROOT/"reports/evaluation.md").read_text()
    for profile in ("baseline","stack-protector-strong","pie-full-relro","fortify-source-3","control-flow-protection","random-layout-seed-101","random-layout-seed-202"): assert profile in text
def test_csv_report_has_both_compilers_and_profiles():
    with (ROOT/"reports/results.csv").open() as f: rows=list(csv.DictReader(f))
    assert len(rows)==14 and {r["compiler"] for r in rows}=={"g++","clang++"}
def test_chart_is_a_png(): assert (ROOT/"reports/overhead.png").read_bytes().startswith(b"\x89PNG\r\n\x1a\n")
def test_binary_report_contains_real_tool_names():
    text=(ROOT/"reports/binary-analysis.md").read_text()
    assert "readelf" in text and "objdump" in text and "GNU_RELRO" in text
