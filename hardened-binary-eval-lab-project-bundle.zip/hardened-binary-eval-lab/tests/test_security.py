import json, pathlib, subprocess
import pytest
ROOT=pathlib.Path(__file__).resolve().parents[1]
RESULTS=json.loads((ROOT/"build/exploits.json").read_text())
@pytest.mark.parametrize("row",RESULTS,ids=lambda r:f"{r['compiler']}-{r['profile']}")
def test_only_baseline_reaches_local_marker(row):
    assert row["marker"] is (row["profile"]=="baseline")
@pytest.mark.parametrize("compiler",["g++","clang++"])
def test_both_layout_seeds_move_the_demo_symbol(compiler):
    for seed in (101,202):
        row=next(r for r in RESULTS if r["compiler"]==compiler and r["profile"]==f"random-layout-seed-{seed}")
        assert row["symbol_changed"] and not row["marker"]
@pytest.mark.parametrize("profile",["baseline","stack-protector-strong","pie-full-relro","fortify-source-3","control-flow-protection","random-layout-seed-101","random-layout-seed-202"])
def test_probe_records_target_and_return_code(profile):
    assert all(r["target_address"].startswith("0x") and isinstance(r["returncode"],int) for r in RESULTS if r["profile"]==profile)
